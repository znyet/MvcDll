﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace TestWebApi
{
    public class MultipartForm
    {
        public NameValueCollection FormData = new NameValueCollection();
        public ConcurrentDictionary<string, byte[]> Files = new ConcurrentDictionary<string, byte[]>();

        public async Task Load(HttpContent content)
        {
            var provider = new MultipartMemoryStreamProvider();
            await content.ReadAsMultipartAsync(provider);
            foreach (var item in provider.Contents)
            {
                var bytes = await item.ReadAsByteArrayAsync();

                if (item.Headers.ContentDisposition.FileName == null) //post参数
                {
                    var name = item.Headers.ContentDisposition.Name.Replace("\"", "");
                    var value = Encoding.UTF8.GetString(bytes);
                    FormData.Add(name, value);
                }
                else //文件  
                {
                    if (bytes.Length != 0)
                    {
                        var name = item.Headers.ContentDisposition.FileName.Replace("\"", ""); //文件名称
                        Files.TryAdd(name, bytes);
                    }
                }
            }
        }
    }
}
