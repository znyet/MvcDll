﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace TestWebApi.Controllers
{
    public class HomeController : ApiController
    {

        /***************************Get请求***********************************/

        [HttpGet]
        public HttpResponseMessage GetByParam(string id, int sex, string name)
        {
            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(id + sex + name, Encoding.UTF8, "text/plain")
                //Content = new StringContent(jsonStr, Encoding.UTF8, "text/json")
            };
            return result;
        }

        [HttpGet]
        public HttpResponseMessage GetByModel([FromUri]People p)
        {
            string data = p.id + p.sex + p.name;
            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(data, Encoding.UTF8, "text/plain")
            };
            return result;
        }


        /***************************Post请求***********************************/

        [HttpPost]
        public HttpResponseMessage PostString([FromBody]string data)
        {
            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(data, Encoding.UTF8, "text/plain")
            };
            return result;
        }


        [HttpPost]
        public HttpResponseMessage PostModel([FromBody]People param)
        {
            string data = param.id + param.sex + param.name;
            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(data, Encoding.UTF8, "text/plain")
            };
            return result;
        }

        [HttpPost]
        public HttpResponseMessage PostDynamic([FromBody]dynamic param)
        {
            string data = param.id + param.sex + param.name;
            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(data, Encoding.UTF8, "text/plain")
            };
            return result;
        }

        [HttpPost]
        public HttpResponseMessage PostStringAndParam([FromBody]string data, string id, string name)
        {
            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(data + id + name, Encoding.UTF8, "text/plain")
            };
            return result;
        }


        /***************************Post File***********************************/

        /// <summary>
        /// 上传文件和参数
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<HttpResponseMessage> PostFile(string bb, string cc)
        {

            //if (!Request.Content.IsMimeMultipartContent())
            //{
            //    throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            //}

            Console.WriteLine(bb + cc);

            var provider = new MultipartMemoryStreamProvider();
            await Request.Content.ReadAsMultipartAsync(provider);

            foreach (var item in provider.Contents)
            {
                var bytes = await item.ReadAsByteArrayAsync(); 

                if (item.Headers.ContentDisposition.FileName == null) //post参数
                {
                    Console.WriteLine(item.Headers.ContentDisposition.Name.Replace("\"", "")); //post key
                    Console.WriteLine(Encoding.UTF8.GetString(bytes)); //post value
                }
                else //文件  
                {
                    // 获取到流
                    var name = item.Headers.ContentDisposition.FileName.Replace("\"", ""); //文件名称
                    Console.WriteLine(name);
                    if (bytes != null && bytes.Length > 0)
                    {
                        string savePath = AppDomain.CurrentDomain.BaseDirectory + name;
                        File.WriteAllBytes(savePath, bytes);
                    }
                }
            }

            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("", Encoding.UTF8, "text/html")
            };
            return result;
        }

        [HttpPost]
        public async Task<HttpResponseMessage> PostFile2(string bb, string cc)
        {
            var form = new MultipartForm();
            await form.Load(Request.Content);
            foreach (var key in form.FormData.AllKeys)
            {
                var msg = string.Format("{0}====>{1}", key, form.FormData[key]);
                Console.WriteLine(msg);
            }

            foreach (var key in form.Files.Keys)
            {
                var msg = string.Format("{0}====>{1}", key, form.Files[key].Length);
                Console.WriteLine(msg);
            }

            //save file
            foreach (var key in form.Files.Keys)
            {
                string savePath = AppDomain.CurrentDomain.BaseDirectory + key;
                File.WriteAllBytes(savePath, form.Files[key]);
            }

            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("ok", Encoding.UTF8, "text/html")
            };
            return result;
        }


        /***************************Post Stream***********************************/

        /// <summary>
        /// 上传流数据
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<HttpResponseMessage> PostStream()
        {
            byte[] data = await Request.Content.ReadAsByteArrayAsync();

            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(Encoding.UTF8.GetString(data), Encoding.UTF8, "text/html")
            };
            return result;
        }

        /***************************Download***********************************/

        /// <summary>
        /// 下载文件
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public HttpResponseMessage Download()
        {
            var stream = new FileStream("D:\\资料.txt", FileMode.Open);
            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StreamContent(stream)
            };
            result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
            result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment") { FileName = "1.txt" };
            return result;
        }


        public class People
        {
            public string id { get; set; }
            public string name { get; set; }
            public int sex { get; set; }


        }

    }
}
