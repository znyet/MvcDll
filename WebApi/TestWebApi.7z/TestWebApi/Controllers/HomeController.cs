﻿using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace TestWebApi.Controllers
{
    public class HomeController : BaseController
    {
        [HttpGet]
        public HttpResponseMessage Get()
        {
            var nav = RequestQuery();
            foreach (var key in nav.AllKeys)
            {
                Console.WriteLine(key + "=====>" + nav[key]);
            }
            return StringData("我是Get");

        }

        [HttpPost]
        public async Task<HttpResponseMessage> Post()
        {
            var nav2 = await RequestForm();
            foreach (var key in nav2.AllKeys)
            {
                Console.WriteLine(key + "=====>" + nav2[key]);
            }

            return StringData("我是Post");
        }

        [HttpPost]
        public async Task<HttpResponseMessage> PostFile()
        {
            var files = await RequestFiles();

            foreach (var dict in files)
            {
                Console.WriteLine(dict.Key);
            }

            var nav2 = await RequestForm();
            foreach (var key in nav2.AllKeys)
            {
                Console.WriteLine(key + "=====>" + nav2[key]);
            }

            return StringData("我是PostFile");
        }

        [HttpPost]
        public async Task<HttpResponseMessage> PostStream()
        {
            var data = await RequestStream();
            Console.WriteLine(Encoding.UTF8.GetString(data));
            return StringData("我是PostStream");
        }

        [HttpGet]
        public HttpResponseMessage DownLoad()
        {
            return FileData("C:\\1.txt", "哈哈.txt");
        }


    }
}
