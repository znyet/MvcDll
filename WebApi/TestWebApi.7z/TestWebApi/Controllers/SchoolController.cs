﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace TestWebApi.Controllers
{
    public class SchoolController:ApiController
    {
        [HttpGet]
        public HttpResponseMessage Index()
        {
            
            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("School Index", Encoding.UTF8, "text/plain")
            };
            return result;
        }
    }
}
