﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TestWebApi
{
    class StaticFilesMessageHandler : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request, CancellationToken cancellationToken)
        {
            return Task.Run(() =>
            {
                var result = new HttpResponseMessage(HttpStatusCode.OK);
                FileStream stream = null;
                try
                {
                    var url = request.RequestUri.AbsolutePath;
                    var ext = Path.GetExtension(url);
                    var path = AppDomain.CurrentDomain.BaseDirectory + url;

                    if (ext == ".html" || ext == ".htm")
                    {
                        var html = File.ReadAllText(path);
                        result.Content = new StringContent(html, Encoding.UTF8, "text/html");
                        return result;
                    }

                    string mediaType;
                    switch (ext)
                    {
                        case ".js":
                            mediaType = "application/x-javascript";
                            break;
                        case ".css":
                            mediaType = "text/css";
                            break;
                        case ".jpg":
                            mediaType = "image/jpeg";
                            break;
                        case ".gif":
                            mediaType = "image/gif";
                            break;
                        case ".png":
                            mediaType = "image/png";
                            break;
                        case ".zip":
                            mediaType = "application/zip";
                            break;
                        case ".rar":
                            mediaType = "application/x-rar-compressed";
                            break;
                        default:
                            mediaType = "application/octet-stream";
                            break;
                    }

                    var fileName = Path.GetFileName(url);
                    stream = new FileStream(path, FileMode.Open);
                    result.Content = new StreamContent(stream);
                    result.Content.Headers.ContentType = new MediaTypeHeaderValue(mediaType);
                    result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment") { FileName = fileName };
                    return result;

                }
                catch (Exception ex)
                {
                    if (stream != null)
                        stream.Dispose();

                    result.Content = new StringContent(ex.Message, Encoding.UTF8, "text/plain");
                    return result;
                }

            }, cancellationToken);
        }
    }
}
