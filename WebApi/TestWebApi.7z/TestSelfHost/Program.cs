﻿using System;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.SelfHost;

namespace TestWebApi
{
    class Program
    {
        static void Main(string[] args)
        {
            //必须添加System.Net.Http引用
            var config = new HttpSelfHostConfiguration("http://localhost:8123"); //配置主机
           
            config.Routes.MapHttpRoute(    //配置路由
                "Default", "{controller}/{action}/{id}",
                new { id = RouteParameter.Optional });

            config.EnableCors(new EnableCorsAttribute("*", "*", "*"));

            config.MapHttpAttributeRoutes();

            //config.Filters.Add(new WebApiExceptionFilterAttribute());
            //config.Filters.Add(new WebApiFilter());

            var server = new HttpSelfHostServer(config);
            server.OpenAsync().Wait(); //开启来自客户端的请求

            Console.WriteLine("Press Enter to quit");
            Console.ReadLine();
        }

    }
}
