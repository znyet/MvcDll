﻿
setTimeout(function() {
    document.getElementById("dd").innerText = "你好";
},1000)