﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using RestSharp;

namespace WebApplication2
{
    /// <summary>
    /// PostStream 的摘要说明
    /// </summary>
    public class PostStream : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            byte[] bytes = Encoding.UTF8.GetBytes("你好");
            var client = new RestClient("http://localhost:8123/Home/PostStream");
            var req = new RestRequest("/test.ashx", Method.POST);
            req.AddParameter("a", bytes, ParameterType.RequestBody);
            var res = client.Execute(req);
            context.Response.Write(res.Content);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}