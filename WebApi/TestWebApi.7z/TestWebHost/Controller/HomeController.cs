﻿using System.Net.Http;

namespace TestWebHost.Controller
{
    public class HomeController : BaseController
    {
        public HttpResponseMessage Get()
        {
            return StringData("你好");
        }
    }
}