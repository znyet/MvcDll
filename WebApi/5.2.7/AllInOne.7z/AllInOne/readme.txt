必须添加两个引用
System.Web
System.Net.Http